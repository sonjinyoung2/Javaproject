/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileSystem;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;



public class UserDataFile {
   String userDataPath = "C:\\Users\\one\\Desktop\\userDataFolder";
   File file = new File(userDataPath);
  
   /* public UserDataFile() {
        init();//Exception in thread "AWT-EventQueue-0" java.lang.NullPointerException
    }*/
   
    void setFilePath(String path) {
        userDataPath = path;
    }
    public void init() { //파일 생성 및 데이터 초기화
        
 if (!file.exists()) {
		try{
		    file.mkdir(); //폴더 생성합니다.
		    System.out.println("폴더가 생성되었습니다.");
	        } 
	        catch(Exception e){
                    
		    e.getStackTrace();
		}        
         } else {
		System.out.println("이미 폴더가 생성돼 있습니다.");
	}
    }

   public void write(String[] userData) { //{이름, 번호, 학과, 주민번호} 유저 한명 정보를 파일에 씀.
         try {
            FileWriter fw = new FileWriter(file, true);
            if (file.isFile() && file.canWrite()) {
                 System.out.println("쓸 수 있는 파일");
                for (String str : userData) {
                    fw.append(str);
                    fw.append("\t");
                }
                fw.append("\r");
                fw.close();
                System.out.println("파일 쓰기 완료.");
            }
            else System.out.println("파일이 아니거나 쓸수없는 파일.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
     public int search(String str) {
//사용자를 검색하여 존재하는 라인 숫자를 반환
// -> 삭제하거나, 수정할 때도 결국 사용자를 검색하고 해당 라인이 어딘지 알아야 찾아갈수 있음(순차접근)
        String dataType = str.substring(0, 1); // 입력받은게 번호인지 이름인지 구분하기 위함.
       if(dataType.equals("P") || dataType.equals("S")) dataType = "번호";
       else dataType = "이름";
        //System.out.println(dataType);
        int lineCnt = 0;
        int searchLine = 0;   
        boolean flag =false;
        boolean same=false;
        
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
         //  BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"));
            String line = "";
    
            while ((line = br.readLine()) != null) { // 파일을 모두 읽을 때 까지
                lineCnt++;
                String[] result = line.split("\t");
                if(dataType.equals("번호"))  same = result[1].equals(str);
                else if (dataType.equals("이름")) same = result[0].equals(str);
               // int type = line.indexOf(str);
                if (!same) {
                    System.out.println(lineCnt + "번 줄에는 정보가 존재하지 않습니다");  
                }
                else {         
            System.out.println(lineCnt + "번 줄에 정보가 존재합니다.");
            searchLine = lineCnt;
            System.out.println(line);
            flag=true;
           
                }
            }
            
            br.close();
           
        }//파일의 전체 줄 수(유저데이터 수)만큼 반복.
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
        System.out.println("검색함수 완료");
        if(flag ==false) searchLine = -1;
        return searchLine;
        
        
    }
    public String searchUser(String str){ //사용자를 검색하여  존재하는 해당 라인 전체 반환
        // 즉, 검색한 사용자에 대한 모든 정보를 반환.
        String line = "";
        int searchLine = search(str); 
        if(searchLine == -1) {
            //System.out.println("null임");
            line = "null";
            return line;
            
        }
         //System.out.println("null 아님");
          try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
         //  BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"));
             
            for(int i=0;i<searchLine;i++) {
                line=br.readLine();
            }
            br.close();     
        }//파일의 전체 줄 수(유저데이터 수)만큼 반복.
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }   
         return line;
    }
    public boolean delete(String str){ //이름이나 학번 둘중 하나로 검색해서 삭제. -> 삭제데이터 빼고 다저장해서 덮어쓰기
       int deleteline = search(str)-1; //검색해서 삭제 할 줄이 몇 번째 줄인지 받아옴.
       if(deleteline==-2) {
           System.out.println("--");
           return false;
       }
       String dummy = "";
         try {        
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            String line="";

            for(int i=0; i< deleteline; i++) {
			    line = br.readLine(); //읽으며 이동
			    dummy = dummy + (line + "\r\n" ); 
            } //dummy 스트링 객체 안에는 삭제 할 데이터 빼고 모두 복사되어있음.
        String delData = br.readLine();
         System.out.println("삭제 할 데이터 : " + delData);
         
         while((line = br.readLine())!=null) dummy += (line + "\r\n" ); 
        
         FileWriter fw = new FileWriter(file); //덮어쓰기
         fw.write(dummy);
         
        System.out.println("삭제함수 완료 ");
        br.close();
        fr.close();
        fw.close();
            }
          catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	return true;
    }
    public void modify(String[] userData){ //{이름, 번호, 학과, 주민번호} 항상 두번째 데이터인 번호는 고유함 가정
         delete(userData[1]); // 고유 정보인 학번 or 교수번호를 인자로 주면 검색하여 삭제함.(덮어쓰기)
         write(userData); // 다시 쓰기. 항상 두번째 데이터인 번호는 고유함 가정
    }
    public Object[] getAllData() { // 테이블에 사용하기 위함
        Object[] tableLines={};
            try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);      
            tableLines = br.lines().toArray();
             br.close();
             
            }         
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally{
        
    }
     return tableLines;
    }
    
}
