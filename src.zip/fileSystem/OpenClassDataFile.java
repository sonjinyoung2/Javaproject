/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author one
 */
public class OpenClassDataFile extends ClaDataFile{
    private String ClassDataPath = "C:\\Users\\one\\Desktop\\ClassDataFolder\\OpenClassDataFile.txt";
    
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
    
      @Override
    public void init() { //파일 생성 및 데이터 초기화
        super.init();
        setFilePath(ClassDataPath);
        
        if(!file.exists()) {
             try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            String[][] openclassData =  {
            };
            for(int i=0;i<openclassData.length;i++) {
                write(openclassData[i]);
            }
        }
        else System.out.println("이미 존재하는 파일");
}
}
