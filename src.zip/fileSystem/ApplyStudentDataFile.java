/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author one
 */
public class ApplyStudentDataFile extends ClaDataFile{
     private String ClassDataPath = "C:\\Users\\one\\Desktop\\ClassDataFolder\\ApplyStudentDataFile.txt";
     @Override
           
   void setFilePath(String path) {
        file = new File(path);
    }
   
    @Override
    public void init() { //파일 생성 및 데이터 초기화
        super.init();//전체 폴더생성
        setFilePath(ClassDataPath);// 경로 변경
        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            
            String[][] applyStudentData =  {{"학번","이름","학과","16", "청구 금액"},
                {"20211234","김수연","컴퓨터소프트웨어과","15", "청구 금액1"},
                {"20216789","박재희","전산학과","18", "청구 금액2"}                  
            };
            for(int i=0;i<applyStudentData.length;i++) {
                write(applyStudentData[i]);
            }
        }
    }
}
