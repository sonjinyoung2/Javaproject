/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class LogInDataFile extends UserDataFile{
    private String logInDataPath =  "C:\\Users\\one\\Desktop\\userDataFolder\\loginDataFile.txt";
 //   private String stuDataPath = "C:\\Users\\내 문서\\Desktop\\userDataFolder\\stuDataFile.txt";
   
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
    @Override
    public void init() { //파일 생성 및 데이터 초기화(초기 데이터는 학사담당자, 수업담당자만)
        super.init();//전체 폴더생성
        setFilePath(logInDataPath);// 경로 변경

        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            
            String[][] userData =  {{"D000", "0000000"},
                {"G000","1111111"}
            };
            for(int i=0;i<userData.length;i++) {
                write(userData[i]);
            }
            setUserDataFile();// 학생과 교수의 정보 파일에서 아이디(학번, 교수번호)와 초기 비밀번호(주민등록번호)만 복사해옴
            //Object[] tableLines = super.getAllData();    
        }
        else System.out.println("이미 존재하는 로그인 파일");
        //Desktop.getDesktop().edit(file); 
     }
    public void setUserDataFile() { 
        UserDataFile file = new StuDataFile(); 
        file.init();
        Object[] stuData = file.getAllData();    
        file = new ProDataFile();
        file.init();
        Object[] proData = file.getAllData();   
        file = new LogInDataFile();
        file.init();
         for (int i = 0; i < stuData.length; i++) {
            String line = stuData[i].toString().trim();
            String[] data = line.split("\t"); // 0번 : 아이디 , 3번 : 초기 비밀번호 
            String[] loginData = {data[1],data[3]};
            file.write(loginData);
        }
         for (int i = 0; i < proData.length; i++) {
            String line = proData[i].toString().trim();
            String[] data = line.split("\t"); // 0번 : 아이디 , 3번 : 초기 비밀번호 
            String[] loginData = {data[1],data[3]};
            file.write(loginData);

        }
    }
    @Override
     public void modify(String[] userData){ //{아이디(학번), 비밀번호}
         delete(userData[0]); // ,로그인 파일에서 해당 데이터 삭제
         write(userData); // 다시 쓰기.
    }
}
