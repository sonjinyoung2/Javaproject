/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.deptGUI;

import javaProject.fileSystem.ProDataFile;
import javaProject.fileSystem.StuDataFile;

/**
 *
 * @author 내 문서
 */
public class DeptManagerProInfo extends DeptManagerUserInfo {

    @Override
   public void setFile() {
       this.file = new ProDataFile();
       file.init();
   }
   @Override
   public void setTitle() {
       this.title[0]="이름";
       this.title[1]="교수번호";
       this.title[2]="학과";
       this.title[3]="주민등록번호";
   }
   @Override
   public void setText() {
       this.labelTitle.setText("교수 정보관리");
       this.labelAllCnt.setText("전체 교수 정보 수");
       this.textUserNum.setText("교수 번호");
   }
}

