/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.fileSystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class StuApplyDataFile extends UserDataFile{
    private String stuApplyDataPath =  "C:\\userDataFolder\\stuApplyDataFile.txt";
 //   private String stuDataPath = "C:\\Users\\내 문서\\Desktop\\userDataFolder\\stuDataFile.txt";
   
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
     @Override
    public void init() { //파일 생성 및 데이터 초기화
       // super.init();
        setFilePath(stuApplyDataPath);
        if(!file.exists()) {
             try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }}
        else System.out.println("이미 존재하는 파일");
}
         
     public void modifyClass (String id){ //{이름, 번호, 학과, 주민번호} 항상 두번째 데이터인 번호는 고유함 가정
          String str= searchUser(id);
        String[] data = str.split("\t");
        String[] modify = data[1].split("/");
        String[] newLine= new String[modify.length-1];
        for(int i=0;i<modify.length-1;i++) {
            newLine[i]=modify[i];
        }
         try {
            FileWriter fw = new FileWriter(file, true);
          
             delete(id);
             fw.append(id);
             fw.append("\t");
             for(int i=0;i<modify.length-1;i++) {
                  
                fw.append(newLine[i]);
                if(i==modify.length-2) {
                    break;
                }
                fw.append("/");
              
              //  System.out.println("파일 쓰기 완료.");
            }
            fw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//        delete(userData[0]); // 고유 정보인 학번 or 교수번호를 인자로 주면 검색하여 삭제함.(덮어쓰기)
//        
//        
//         write(userData); // 다시 쓰기. 항상 두번째 데이터인 번호는 고유함 가정
    
    @Override
    public void write(String[] userData) { //{이름, 번호, 학과, 주민번호} 유저 한명 정보를 파일에 씀.
         try {
            FileWriter fw = new FileWriter(file, true);
            if (file.isFile() && file.canWrite()) {
             //    System.out.println("쓸 수 있는 파일");
             if(search(userData[0])==-1) {//새로운 학생에 대한 수강정보라면
                 fw.append(userData[0]);
                 fw.append("\t");
                 fw.append(userData[1]);
                 //fw.append("/");
             }
             else { //원래 있던 학생에 대한 수강정보라면 
                   String str = searchUser(userData[0]);
                   delete(userData[0]);
                   String newStr = str+"/"+userData[1];
                  
                  fw.write(newStr);
             }    
             fw.write("\r\n");
                fw.close();
              //  System.out.println("파일 쓰기 완료.");
            }
            else System.out.println("파일이 아니거나 쓸수없는 파일.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}