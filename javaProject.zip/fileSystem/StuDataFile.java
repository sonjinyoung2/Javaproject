/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class StuDataFile extends UserDataFile{
    private String stuDataPath = "C:\\userDataFolder\\stuDataFile.txt";
    //File file = new File(stuDataPath);
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
    @Override
    public void init() { //파일 생성 및 데이터 초기화
      //  super.init();//전체 폴더생성
        setFilePath(stuDataPath);// 경로 변경
//        this.userDataPath = stuDataPath;
//        System.out.println(userDataPath);
//        this.file = new File(userDataPath);
        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            
            String[][] userData =  {{"김수민","S001","전산학과","0000000"},
                {"김사람","S002","전자공학과","1111111"},
                 {"이유리","S003","전산학과","2222222"}
//                {"박영수","S004","화학공학과","0000000"},
//                {"김영숙","S005","기계공학과","0000000"},
//                {"김현정","S006","화학공학과","0000000"},
//                {"이수만","S007","전자공학과","0000000"}
                    
            };
            for(int i=0;i<userData.length;i++) {
                write(userData[i]);
            }
        }
        else System.out.println("이미 존재하는 학생 파일");
        //Desktop.getDesktop().edit(file);
        
     }

  
}
