/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class ClassDataFile extends UserDataFile{
    private String ClassDataPath = "C:\\userDataFolder\\ClassDataFile.txt";
    
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
    @Override
    public void init() { //파일 생성 및 데이터 초기화
        super.init();//전체 폴더생성
        setFilePath(ClassDataPath);// 경로 변경
        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            
            String[][] classData =  {{"001","수치해석학","전산학과","3", "간단한 설명"},
                {"002","이산수학","컴퓨터소프트웨어과","2", "간단한 설명"},
                {"003","과학공학","화학공학과","3", "간단한 설명"}                  
            };
            for(int i=0;i<classData.length;i++) {
                write(classData[i]);
            }
        }
    }
}