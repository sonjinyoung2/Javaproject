/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.fileSystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class CountDataFile extends UserDataFile{
    private String countDataFile = "C:\\userDataFolder\\countDataFile.txt";
    //File file = new File(proDataPath);
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
      @Override
    public void init() { //파일 생성 및 데이터 초기화
       // super.init();
        setFilePath(countDataFile);
        
        if(!file.exists()) {
             try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
        else System.out.println("이미 존재하는 학점수 파일");
        
        //Desktop.getDesktop().edit(file);
     }
      public int count(String str) { //학번으로 검색 -총 학점 수 계산
        int cnt = 0;
        setFilePath("C:\\userDataFolder\\stuApplyDataFile.txt");
        String stuApplyDataFileLine = searchUser(str);  // 학번으로 검색
        String[] data = stuApplyDataFileLine.split("\t");
        String [] classNumData = data[1].split("/"); //수강신청 된 강좌 수만큼 배열크기가 나옴.
        setFilePath ("C:\\userDataFolder\\OpenClassDataFile.txt");
       
        for(int i=0;i<classNumData.length;i++) {
            String s = classNumData[i];
            String openClassDataFileLine = searchUser(s);
            String[] data2 = openClassDataFileLine.split("\t");
            cnt += Integer.parseInt(data2[2]);
        }
        System.out.println( str+"학생의 총 학점 수 : " + cnt);
        return cnt;
    }  
      
      public boolean deleteNum(String str){ //이름이나 학번 둘중 하나로 검색해서 삭제. -> 삭제데이터 빼고 다저장해서 덮어쓰기
       int deleteline = search(str)-1; //검색해서 삭제 할 줄이 몇 번째 줄인지 받아옴.
       if(deleteline==-2) {
           System.out.println("파일에 정보 없음");
           return false;
       }
       String dummy = "";
         try {        
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            String line="";

            for(int i=0; i< deleteline; i++) {
			    line = br.readLine(); //읽으며 이동
			    dummy = dummy + (line + "\r\n" ); 
            } //dummy 스트링 객체 안에는 삭제 할 데이터 빼고 모두 복사되어있음.
        String delData = br.readLine();
         System.out.println("삭제 할 데이터 : " + delData);
         
         while((line = br.readLine())!=null) dummy += (line + "\r\n" ); 
        
         FileWriter fw = new FileWriter(file); //덮어쓰기
         fw.write(dummy);
         
        System.out.println("삭제함수 완료 ");
        br.close();
        fr.close();
        fw.close();
            }
          catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	return true;
    }
}

