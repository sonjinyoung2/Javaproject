/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.fileSystem;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author 내 문서
 */
public class ProDataFile extends UserDataFile{
    private String proDataPath = "C:\\userDataFolder\\proDataFile.txt";
    //File file = new File(proDataPath);
    @Override
   void setFilePath(String path) {
        file = new File(path);
    }
      @Override
    public void init() { //파일 생성 및 데이터 초기화
       // super.init();
        setFilePath(proDataPath);
        
        if(!file.exists()) {
             try {
                file.createNewFile();
            } catch(IOException e) {
                e.printStackTrace();
            }
            String[][] userData =  { {"김교수","P001","화학공학과","0000000"},
                 {"박교수","P002","항공우주공학과","0000000"},
                 {"이교수","P003","전산학과","0000000"}
//                 {"정교수","P004","화학공학과","0000000"},
//                 {"윤교수","P005","항공우주공학과","0000000"},
//                 {"박철수","P006","전산학과","0000000"},
//                 {"김영자","P007","화학공학과","0000000"},
//                 {"김철수","P008","항공우주공학과","0000000"},
//                 {"백교수","P009","전산학과","0000000"},
//                 {"전교수","P010","화학공학과","0000000"}  
            };
            for(int i=0;i<userData.length;i++) {
                write(userData[i]);
            }
        }
        else System.out.println("이미 존재하는 교수 파일");
        
        //Desktop.getDesktop().edit(file);
     }

   
  
}
