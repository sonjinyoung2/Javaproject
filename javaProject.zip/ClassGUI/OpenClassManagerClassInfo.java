
package javaProject.ClassGUI;

import javaProject.fileSystem.OpenClassDataFile;
import javaProject.fileSystem.ClassDataFile;

/**
 *
 * @author one
 */
public class OpenClassManagerClassInfo extends OpenClassManagerClaInfo {

    @Override
   public void setFile() {
       this.file=new ClassDataFile();
       file.init();
       this.ofile = new OpenClassDataFile();
       ofile.init();
   }
   
   @Override
   public void setTitle() {
       this.title[0]="강좌 번호";
       this.title[1]="강좌 이름";
       this.title[2]="학점 수";
       this.title[3]="담당 교수";
       this.title[4]="학과";
       this.title[5]="최소 학생 수";
       this.title[6]="최대 학생 수";
       this.title[7]="교수 ID";
   }
}
