package javaProject.ClassGUI;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import javaProject.fileSystem.ClassDataFile;
import javax.swing.JOptionPane;

/**
 *
 * @author one
 */

public abstract class ClassManagerOpenCla extends javax.swing.JFrame {

    String deptId="";
    String deptPw="";
    DefaultTableModel model;
    ClassDataFile file = new ClassDataFile();
    String[] title = {"","","","",""};

    public ClassManagerOpenCla() {
        initComponents();
    }
    public void initialize() { // 화면구성
       
        setTable();
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    public abstract void setFile();
    public abstract void setTitle();
    
    public void setTable() {
        jTableClassInfo.setAutoCreateRowSorter(true);
        model = (DefaultTableModel) jTableClassInfo.getModel();
        model.setNumRows(0);
        setTitle();
        model.setColumnIdentifiers(title);
        
        Object[] tableLines = file.getAllData();
        
        for (int i = 0; i < tableLines.length; i++) {
            String line = tableLines[i].toString().trim();
            String[] data = line.split("\t");
            model.addRow(data);

        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        searchFrame = new javax.swing.JFrame();
        searchField = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        resultText = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        modifyFrame = new javax.swing.JFrame();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        modifySearchField = new javax.swing.JTextField();
        btnMfOk = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        textFieldNum = new javax.swing.JTextField();
        textFieldName = new javax.swing.JTextField();
        textFieldDept = new javax.swing.JTextField();
        textFieldCNum = new javax.swing.JTextField();
        btnInput = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        textFieldCinfo = new javax.swing.JTextField();
        addFrame = new javax.swing.JFrame();
        textFieldName1 = new javax.swing.JTextField();
        textFieldDept1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textFieldCnum1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textUserNum = new javax.swing.JLabel();
        btnMfOk1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        textFieldNum1 = new javax.swing.JTextField();
        textFieldCinfo1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableClassInfo = new javax.swing.JTable();
        jButtClassSearch = new javax.swing.JButton();
        jButtClassModify = new javax.swing.JButton();
        jButtClassAdd = new javax.swing.JButton();
        jButtClassDelete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabelClassInfo = new javax.swing.JLabel();
        labelAllCnt = new javax.swing.JLabel();
        allClassCnt = new javax.swing.JLabel();

        searchField.setForeground(new java.awt.Color(153, 153, 153));
        searchField.setText("이름 또는 번호로 검색하세요.");
        searchField.setName(""); // NOI18N
        searchField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchFieldMouseClicked(evt);
            }
        });
        searchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFieldActionPerformed(evt);
            }
        });
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchFieldKeyPressed(evt);
            }
        });

        btnSearch.setText("검색");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        jLabel2.setText("검색 결과");

        resultText.setColumns(20);
        resultText.setRows(5);
        jScrollPane3.setViewportView(resultText);

        jButton4.setText("취소");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout searchFrameLayout = new javax.swing.GroupLayout(searchFrame.getContentPane());
        searchFrame.getContentPane().setLayout(searchFrameLayout);
        searchFrameLayout.setHorizontalGroup(
            searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(searchFrameLayout.createSequentialGroup()
                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        searchFrameLayout.setVerticalGroup(
            searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchFrameLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addGroup(searchFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(searchFrameLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel2))
                    .addGroup(searchFrameLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel4.setText("변경할 강좌 번호");

        jLabel5.setText("변경할 담당 학과");

        jLabel6.setText("변경할 강좌 이름 ");

        modifySearchField.setForeground(new java.awt.Color(153, 153, 153));
        modifySearchField.setText("변경할 사용자의 번호를 입력하세요.");
        modifySearchField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                modifySearchFieldMouseClicked(evt);
            }
        });
        modifySearchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                modifySearchFieldKeyPressed(evt);
            }
        });

        btnMfOk.setText("확인");
        btnMfOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMfOkActionPerformed(evt);
            }
        });

        jButton2.setText("취소");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("변경할 학점 수");

        btnInput.setText("입력");
        btnInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInputActionPerformed(evt);
            }
        });

        jLabel8.setText("변경할 강좌 정보 ");

        javax.swing.GroupLayout modifyFrameLayout = new javax.swing.GroupLayout(modifyFrame.getContentPane());
        modifyFrame.getContentPane().setLayout(modifyFrameLayout);
        modifyFrameLayout.setHorizontalGroup(
            modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modifyFrameLayout.createSequentialGroup()
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modifyFrameLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(modifySearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnInput))
                    .addGroup(modifyFrameLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(44, 44, 44)
                        .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(modifyFrameLayout.createSequentialGroup()
                                .addComponent(textFieldCNum, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textFieldDept, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldNum, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCinfo, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(modifyFrameLayout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(btnMfOk, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        modifyFrameLayout.setVerticalGroup(
            modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modifyFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modifySearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInput))
                .addGap(15, 15, 15)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldDept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldCNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modifyFrameLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(textFieldCinfo, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(modifyFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMfOk)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        jLabel9.setText("강좌 번호");

        jLabel10.setText("담당 학과");

        textUserNum.setText("강좌 이름");

        btnMfOk1.setText("확인");
        btnMfOk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMfOk1ActionPerformed(evt);
            }
        });

        jLabel11.setText("학점 수");

        jLabel12.setFont(new java.awt.Font("맑은 고딕", 0, 14)); // NOI18N
        jLabel12.setText("강좌 정보 추가");

        jLabel13.setText("강좌 정보");

        jButton3.setText("취소");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addFrameLayout = new javax.swing.GroupLayout(addFrame.getContentPane());
        addFrame.getContentPane().setLayout(addFrameLayout);
        addFrameLayout.setHorizontalGroup(
            addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addFrameLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addFrameLayout.createSequentialGroup()
                        .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textUserNum, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(44, 44, 44)
                        .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFieldName1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldNum1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldDept1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCnum1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCinfo1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(addFrameLayout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addFrameLayout.createSequentialGroup()
                        .addComponent(btnMfOk1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        addFrameLayout.setVerticalGroup(
            addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldNum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textUserNum))
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldDept1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldCnum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(textFieldCinfo1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(addFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMfOk1)
                    .addComponent(jButton3))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTableClassInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableClassInfo.setName(""); // NOI18N
        jScrollPane2.setViewportView(jTableClassInfo);

        jButtClassSearch.setText("강좌 검색");
        jButtClassSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtClassSearchActionPerformed(evt);
            }
        });

        jButtClassModify.setText("강좌 수정");
        jButtClassModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtClassModifyActionPerformed(evt);
            }
        });

        jButtClassAdd.setText("강좌 추가");
        jButtClassAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtClassAddActionPerformed(evt);
            }
        });

        jButtClassDelete.setText("강좌 삭제");
        jButtClassDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtClassDeleteActionPerformed(evt);
            }
        });

        jButton1.setText("뒤로가기");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabelClassInfo.setFont(new java.awt.Font("맑은 고딕", 0, 15)); // NOI18N
        jLabelClassInfo.setText("수업 정보 관리");

        labelAllCnt.setText("전체 강좌 수 ");

        allClassCnt.setForeground(new java.awt.Color(0, 204, 204));
        allClassCnt.setText("0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelClassInfo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(labelAllCnt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(allClassCnt, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButtClassSearch)
                        .addGap(83, 83, 83)
                        .addComponent(jButtClassModify)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                        .addComponent(jButtClassAdd)
                        .addGap(96, 96, 96)
                        .addComponent(jButtClassDelete)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabelClassInfo))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelAllCnt)
                    .addComponent(allClassCnt))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtClassSearch)
                    .addComponent(jButtClassModify)
                    .addComponent(jButtClassAdd)
                    .addComponent(jButtClassDelete))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtClassSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtClassSearchActionPerformed
        // TODO add your handling code here:
        searchFrame.setVisible(true);
        searchFrame.setTitle("강좌 정보 검색");
        searchFrame.setSize(350,260);
        searchFrame.setLocation(900,250);
        searchFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        searchField.setText("이름 혹은 번호로 검색해주세요.");
        searchField.setForeground(Color.GRAY);
        resultText.setText("");
        clickOnce=false;
        typeOnce = false;
    }//GEN-LAST:event_jButtClassSearchActionPerformed

    private void btnClassSearchActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
        String str="";
        String line="";
        str=searchField.getText();
        line =file.searchUser(str); //실제 파일에서 검색
        
        if(line.equals("null")) { // 유저 정보를 찾을 수 없는 경우.
            System.out.println(line);
            resultText.setText("");
            //resultText.append(str +" 의 정보가 존재하지 않습니다.\n\n\n");           
            JOptionPane.showMessageDialog(null, "정보가 존재하지 않습니다.", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] classData = line.split("\t");
        resultText.append("======================================\n");
        resultText.append("강좌 번호 : " + classData[0] + "\n");
        resultText.append("강좌 이름 : " + classData[1] + "\n");
        resultText.append("담당 학과 : " + classData[2] + "\n");
        resultText.append("학점 수 : " + classData[3] + "\n");
        resultText.append("강좌 정보 : " + classData[4] + "\n");
    }
    
    private void jButtClassModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtClassModifyActionPerformed
        // TODO add your handling code here:
        modifyFrame.setVisible(true);
    modifyFrame.setTitle("강좌 정보 수정");
    modifyFrame.setSize(600,400);  
    modifyFrame.setLocation(900,250);    
    modifyFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
     modifySearchField.setText("변경할 강좌의 번호를 입력하세요.");
      modifySearchField.setForeground(Color.gray);
     textFieldName.setText("");
     textFieldNum.setText("");
     textFieldDept.setText("");
     textFieldCNum.setText("");
     textFieldCinfo.setText("");
     
     clickOnce=false;
     typeOnce = false;

    }//GEN-LAST:event_jButtClassModifyActionPerformed

    private void jButtClassAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtClassAddActionPerformed
        // TODO add your handling code here:
        addFrame.setVisible(true);
        addFrame.setTitle("강좌 추가");
        addFrame.setSize(350,450);
        addFrame.setLocation(900,250);
        addFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButtClassAddActionPerformed

    
    private void jButtClassDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtClassDeleteActionPerformed
        // TODO add your handling code here:
        int index = jTableClassInfo.getSelectedRow();
        if(index < 0){
            JOptionPane.showMessageDialog(null,"삭제할 행을 선택해 주세요.");
        }else{
            String str = (String)(jTableClassInfo.getValueAt(index, 1));
            System.out.println(index);

            System.out.println(str);
            file.delete(str);

            model.removeRow(index);

            JOptionPane.showMessageDialog(null,"정보가 삭제되었습니다.");
            setTable();}
    }//GEN-LAST:event_jButtClassDeleteActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void searchFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchFieldMouseClicked
        // TODO add your handling code here:
        if(!clickOnce) {
            searchField.setText("");
            searchField.setForeground(Color.black);
            clickOnce = true;
        }
    }//GEN-LAST:event_searchFieldMouseClicked

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldActionPerformed

    private void searchFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyPressed
        if(!typeOnce) {
            searchField.setText("");
            searchField.setForeground(Color.black);
            typeOnce = true;
        }
    }//GEN-LAST:event_searchFieldKeyPressed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // TODO add your handling code here:
        String str="";
        String line="";
        str=searchField.getText();
        line =file.searchUser(str); //실제 파일에서 검색

        if(line.equals("null")) { // 강좌 정보를 찾을 수 없는 경우.
            System.out.println(line);
            resultText.setText("");
            //resultText.append(str +" 의 정보가 존재하지 않습니다.\n\n\n");
            JOptionPane.showMessageDialog(null, "정보가 존재하지 않습니다.", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] classData = line.split("\t");
        resultText.append("======================================\n");
        resultText.append("강좌 번호 : " + classData[0] + "\n");
        resultText.append("강좌 이름 : " + classData[1] + "\n");
        resultText.append("강좌 학과 : " + classData[2] + "\n");
        resultText.append("학점 수 : " + classData[3] + "\n");
        resultText.append("강좌 정보 : " + classData[4] + "\n");
        
    }//GEN-LAST:event_btnSearchActionPerformed

    private void modifySearchFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modifySearchFieldMouseClicked
        // TODO add your handling code here:
        if(!clickOnce) {
            modifySearchField.setText("");
            modifySearchField.setForeground(Color.black);
            clickOnce = true;
        }

    }//GEN-LAST:event_modifySearchFieldMouseClicked

    private void modifySearchFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_modifySearchFieldKeyPressed
        // TODO add your handling code here:

        if(!typeOnce) {
            modifySearchField.setText("");
            modifySearchField.setForeground(Color.black);
            typeOnce = true;
        }
    }//GEN-LAST:event_modifySearchFieldKeyPressed

    private void btnMfOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMfOkActionPerformed
        // TODO add your handling code here:
        System.out.println("ok");
        String[] classData=new String[8];

        classData[0]=textFieldNum.getText();
        classData[1]=textFieldName.getText();
        classData[2]=textFieldDept.getText();
        classData[3]=textFieldCNum.getText();
        classData[4]=textFieldCinfo.getText();
                
        file.modify(classData);
        JOptionPane.showMessageDialog(null, "정보가 변경되었습니다.");
        modifySearchField.setText("");
        textFieldNum.setText("");
        textFieldName.setText("");
        textFieldDept.setText("");
        textFieldCNum.setText("");
        textFieldCinfo.setText("");
        
        setTable();

    }//GEN-LAST:event_btnMfOkActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        modifyFrame.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInputActionPerformed
        // TODO add your handling code here:
        String str = modifySearchField.getText();
        String line = file.searchUser(str);
        System.out.println("입력 정보 찾기");
        if(line.equals("null")) {
            JOptionPane.showMessageDialog(null, "정보가 존재하지 않습니다.", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] classData = line.split("\t");
        textFieldNum.setText(classData[0]);
        textFieldName.setText(classData[1]);
        textFieldDept.setText(classData[2]);
        textFieldCNum.setText(classData[3]);
        textFieldCinfo.setText(classData[4]);
        
    }//GEN-LAST:event_btnInputActionPerformed

    private void btnMfOk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMfOk1ActionPerformed
        // TODO add your handling code here:
        String[] classData={"","","","","",""};
        classData[0]=textFieldNum1.getText();
        classData[1]=textFieldName1.getText();
        classData[2]=textFieldDept1.getText();
        classData[3]=textFieldCnum1.getText();
        classData[4]=textFieldCinfo1.getText();  
        
        file.write(classData);
        JOptionPane.showMessageDialog(null, "정보가 추가되었습니다.");
        textFieldNum1.setText("");
        textFieldName1.setText("");
        textFieldDept1.setText("");
        textFieldCnum1.setText("");
        textFieldCinfo1.setText("");
        setTable();
    }//GEN-LAST:event_btnMfOk1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        addFrame.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        searchFrame.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFrame addFrame;
    private javax.swing.JLabel allClassCnt;
    private javax.swing.JButton btnInput;
    private javax.swing.JButton btnMfOk;
    private javax.swing.JButton btnMfOk1;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton jButtClassAdd;
    private javax.swing.JButton jButtClassDelete;
    private javax.swing.JButton jButtClassModify;
    private javax.swing.JButton jButtClassSearch;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelClassInfo;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTableClassInfo;
    public javax.swing.JLabel labelAllCnt;
    private javax.swing.JFrame modifyFrame;
    private javax.swing.JTextField modifySearchField;
    private javax.swing.JTextArea resultText;
    private javax.swing.JTextField searchField;
    private javax.swing.JFrame searchFrame;
    private javax.swing.JTextField textFieldCNum;
    private javax.swing.JTextField textFieldCinfo;
    private javax.swing.JTextField textFieldCinfo1;
    private javax.swing.JTextField textFieldCnum1;
    private javax.swing.JTextField textFieldDept;
    private javax.swing.JTextField textFieldDept1;
    private javax.swing.JTextField textFieldName;
    private javax.swing.JTextField textFieldName1;
    private javax.swing.JTextField textFieldNum;
    private javax.swing.JTextField textFieldNum1;
    public javax.swing.JLabel textUserNum;
    // End of variables declaration//GEN-END:variables

boolean clickOnce =false;
boolean typeOnce = false;

}
