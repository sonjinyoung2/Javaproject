/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.ClassGUI;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javaProject.fileSystem.ClassDataFile;
import javax.swing.JOptionPane;
import javaProject.fileSystem.OpenClassDataFile;
import javaProject.fileSystem.ProDataFile;
import javaProject.student.ApplyClass;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author one
 */
public abstract class OpenClassManagerClaInfo extends javax.swing.JFrame {
    String[] data;
    String classManagerId="";
    String classManagerPw="";
    DefaultTableModel model;
    OpenClassDataFile ofile = new OpenClassDataFile();
    ClassDataFile file = new ClassDataFile();
    String[] title = {"","","","","","","",""};

    public OpenClassManagerClaInfo() {
        initComponents();
        init();
    }
    public void initialize() { // 화면구성
       
        setTable();
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
  public void init() {//콤보박스 초기화
      DefaultComboBoxModel model = new  DefaultComboBoxModel();
      String fileName = "C:\\userDataFolder\\proDataFile.txt";
      File file = new File(fileName);
      int idx=0;
       String line="";
      try {
           BufferedReader br = new BufferedReader(new FileReader(file));
          while((line=br.readLine())!=null) {
            
              System.out.println(line);
              data = line.split("\t");
              model.addElement(data[0]); //교수 이름
              //data2[idx++] = data[1];
              jComboBox1.setModel(model);

          }
          br.close();
         
      } catch(FileNotFoundException ex) {
          ex.printStackTrace();
      } catch(IOException ex) {
          ex.printStackTrace();
      }
  }
    public abstract void setFile();
    public abstract void setTitle();
    
    public void setTable() {
        jTableClassInfo1.setAutoCreateRowSorter(true);
        model = (DefaultTableModel) jTableClassInfo1.getModel();
        model.setNumRows(0);
        setTitle();
        model.setColumnIdentifiers(title);
        
        Object[] tableLines = ofile.getAllData();
        
        for (int i = 0; i < tableLines.length; i++) {
            String line = tableLines[i].toString().trim();
            String[] data = line.split("\t");
            model.addRow(data);
            
            String cnt = (model.getRowCount())+"";
            allOpenClassCnt.setText(cnt);

        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        openFrame = new javax.swing.JFrame();
        textUserNum = new javax.swing.JLabel();
        btnMfOk1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        textFieldMiniStu = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        textFieldMaxStu = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnInput = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textFieldCinfo = new javax.swing.JTextField();
        modifySearchField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textFieldNum = new javax.swing.JTextField();
        textFieldName = new javax.swing.JTextField();
        textFieldDept = new javax.swing.JTextField();
        textFieldCNum = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabelClassInfo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        labelAllCnt = new javax.swing.JLabel();
        allOpenClassCnt = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableClassInfo1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();

        textUserNum.setText("담당 교수");

        btnMfOk1.setText("확인");
        btnMfOk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMfOk1ActionPerformed(evt);
            }
        });

        jLabel11.setText("최대 학생 수");

        jButton3.setText("취소");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel10.setText("최소 학생 수");

        jLabel4.setText("강좌 번호");

        btnInput.setText("입력");
        btnInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInputActionPerformed(evt);
            }
        });

        jLabel5.setText("담당 학과");

        jLabel8.setText("강좌 정보 ");

        jLabel6.setText("강좌 이름 ");

        modifySearchField.setForeground(new java.awt.Color(153, 153, 153));
        modifySearchField.setText("개설할 강좌의 번호를 입력하세요.");
        modifySearchField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                modifySearchFieldMouseClicked(evt);
            }
        });
        modifySearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifySearchFieldActionPerformed(evt);
            }
        });
        modifySearchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                modifySearchFieldKeyPressed(evt);
            }
        });

        jLabel7.setText("학점 수");

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout openFrameLayout = new javax.swing.GroupLayout(openFrame.getContentPane());
        openFrame.getContentPane().setLayout(openFrameLayout);
        openFrameLayout.setHorizontalGroup(
            openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(openFrameLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFieldNum, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCNum, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldDept, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textFieldCinfo, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openFrameLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openFrameLayout.createSequentialGroup()
                                        .addComponent(textUserNum)
                                        .addGap(18, 18, 18)
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openFrameLayout.createSequentialGroup()
                                        .addComponent(btnMfOk1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(14, 14, 14))))
                            .addGroup(openFrameLayout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(openFrameLayout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(textFieldMiniStu, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(openFrameLayout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textFieldMaxStu, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))))
                    .addGroup(openFrameLayout.createSequentialGroup()
                        .addComponent(modifySearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnInput)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        openFrameLayout.setVerticalGroup(
            openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modifySearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInput))
                .addGap(27, 27, 27)
                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textFieldNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(openFrameLayout.createSequentialGroup()
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textUserNum)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(openFrameLayout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textFieldMaxStu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11)))
                            .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textFieldMiniStu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10))))
                    .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(openFrameLayout.createSequentialGroup()
                            .addComponent(textFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textFieldDept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5))
                            .addGap(18, 18, 18)
                            .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textFieldCNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7)))
                        .addComponent(jLabel6)))
                .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(openFrameLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFieldCinfo, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(openFrameLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(openFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(btnMfOk1))
                        .addGap(32, 32, 32))))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelClassInfo.setFont(new java.awt.Font("맑은 고딕", 0, 15)); // NOI18N
        jLabelClassInfo.setText("강좌 개설");

        jButton1.setText("뒤로가기");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        labelAllCnt.setText("개설된 강좌 수");

        allOpenClassCnt.setForeground(new java.awt.Color(0, 204, 204));
        allOpenClassCnt.setText("0");

        jButton2.setText("개설");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTableClassInfo1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableClassInfo1.setName(""); // NOI18N
        jScrollPane3.setViewportView(jTableClassInfo1);

        jButton4.setText("개설 취소");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelClassInfo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 568, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(labelAllCnt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(allOpenClassCnt, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelClassInfo)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelAllCnt)
                    .addComponent(allOpenClassCnt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        openFrame.setVisible(true);
        openFrame.setTitle("강좌 개설");
        openFrame.setSize(600,500);
        openFrame.setLocation(900,250);
        openFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnMfOk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMfOk1ActionPerformed
        // TODO add your handling code here:
        String[] openclassData={"","","","","","","",""};
        openclassData[0]=textFieldNum.getText();
        openclassData[1]=textFieldName.getText();
        openclassData[2]=textFieldCNum.getText();
       openclassData[3] = (String)jComboBox1.getSelectedItem(); //교수이름
      ProDataFile file = new ProDataFile();
      file.init();
        String line =   file.searchUser( openclassData[3]);
        String[] data = line.split("\t");
    
        openclassData[4]=textFieldDept.getText();
        openclassData[5]=textFieldMiniStu.getText();
        openclassData[6]=textFieldMaxStu.getText();
        
        openclassData[7]=data[1]; //교수번호
        System.out.println(data[1]);
        
        String str = ofile.searchUser(textFieldNum.getText());
        System.out.println(str);
        boolean pass = str.contains(openclassData[0]);
        
        if(pass){
            JOptionPane.showMessageDialog(null,"중복 개설은 할 수 없습니다.", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            textFieldNum.setText("");
            textFieldName.setText("");
            textFieldDept.setText("");
            textFieldCNum.setText("");
            textFieldCinfo.setText("");
            textFieldMiniStu.setText("");
            textFieldMaxStu.setText("");
            return;
        }
        
        ofile.write(openclassData);
        JOptionPane.showMessageDialog(null, "정보가 추가되었습니다.");
        
        textFieldNum.setText("");
        textFieldName.setText("");
        textFieldDept.setText("");
        textFieldCNum.setText("");
        textFieldCinfo.setText("");
        textFieldMiniStu.setText("");
        textFieldMaxStu.setText("");
     
        setTable();
    }//GEN-LAST:event_btnMfOk1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        openFrame.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInputActionPerformed
        // TODO add your handling code here:
        
        String str = modifySearchField.getText();
        String line = file.searchUser(str);
        System.out.println("입력 정보 찾기");
        if(line.equals("null")) {
            JOptionPane.showMessageDialog(null, "정보가 존재하지 않습니다.", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] classData = line.split("\t");
        textFieldNum.setText(classData[0]);
        textFieldName.setText(classData[1]);
        textFieldDept.setText(classData[2]);
        textFieldCNum.setText(classData[3]);
        textFieldCinfo.setText(classData[4]);

    }//GEN-LAST:event_btnInputActionPerformed

    private void modifySearchFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modifySearchFieldMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_modifySearchFieldMouseClicked

    private void modifySearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifySearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modifySearchFieldActionPerformed

    private void modifySearchFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_modifySearchFieldKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_modifySearchFieldKeyPressed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         int index = jTableClassInfo1.getSelectedRow();
        if(index < 0){
            JOptionPane.showMessageDialog(null,"삭제할 행을 선택해 주세요.");
        }else{
            String str = (String)(jTableClassInfo1.getValueAt(index, 1));
            System.out.println(index);

            System.out.println(str);
            
            ofile.opendelete(str);

            model.removeRow(index);

            JOptionPane.showMessageDialog(null,"정보가 삭제되었습니다.");
            setTable();}
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

    }//GEN-LAST:event_jComboBox1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel allOpenClassCnt;
    private javax.swing.JButton btnInput;
    private javax.swing.JButton btnMfOk1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabelClassInfo;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTableClassInfo1;
    public javax.swing.JLabel labelAllCnt;
    private javax.swing.JTextField modifySearchField;
    private javax.swing.JFrame openFrame;
    private javax.swing.JTextField textFieldCNum;
    private javax.swing.JTextField textFieldCinfo;
    private javax.swing.JTextField textFieldDept;
    private javax.swing.JTextField textFieldMaxStu;
    private javax.swing.JTextField textFieldMiniStu;
    private javax.swing.JTextField textFieldName;
    private javax.swing.JTextField textFieldNum;
    public javax.swing.JLabel textUserNum;
    // End of variables declaration//GEN-END:variables
}
