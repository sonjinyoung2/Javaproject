/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaProject.ClassGUI;

import javaProject.fileSystem.ClassDataFile;
import javaProject.fileSystem.OpenClassDataFile;

/**
 *
 * @author one
 */
public class ClassManagerClassInfo extends ClassManagerClaInfo {

    @Override
   public void setFile() {
       this.file = new ClassDataFile();
       file.init();
   }
   @Override
   public void setTitle() {
       this.title[0]="강좌 번호";
       this.title[1]="강좌 이름";
       this.title[2]="담당 학과";
       this.title[3]="학점 수";
       this.title[4]="강좌 정보";
   }
}